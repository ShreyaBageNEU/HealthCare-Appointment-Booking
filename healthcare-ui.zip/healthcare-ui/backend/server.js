const express = require('express');
const cors = require('cors');
const mysql = require('mysql');

const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost', 
  user: 'root', 
  password: 'root',
  database: 'ohabp'
});

const app = express();
app.use(cors());
app.use(express.json());

// Node.js Express backend
const cors = require('cors');
app.use(cors());



// Endpoint to fetch appointments
app.get('/appointments', (req, res) => {
  pool.query('SELECT * FROM Appointment', (error, results) => {
    if (error) {
      return res.status(500).json({ error });
    }
    res.json(results);
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
